"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function PatientNavigation() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Hospital Navigation</CardTitle>
        <CardDescription>Your current location and next destination</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
            <p className="font-medium text-blue-900">Current Location: Reception</p>
            <p className="text-sm text-blue-700 mt-1">Please proceed to the registration desk</p>
          </div>
          <div className="p-4 bg-green-50 rounded-lg border border-green-200">
            <p className="font-medium text-green-900">Next: Doctor Consultation</p>
            <p className="text-sm text-green-700 mt-1">Room 101 - Dr. Smith</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"
import type { AuthState } from "./types"

interface AuthContextType extends AuthState {
  login: (username: string, password: string) => Promise<void>
  signup: (data: any) => Promise<void>
  logout: () => void
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [authState, setAuthState] = useState<AuthState>({
    user: null,
    isAuthenticated: false,
    loading: true,
  })

  // Load user from localStorage on mount
  useEffect(() => {
    const storedUser = localStorage.getItem("hospital_user")
    if (storedUser) {
      try {
        const user = JSON.parse(storedUser)
        setAuthState({
          user,
          isAuthenticated: true,
          loading: false,
        })
      } catch (error) {
        setAuthState({ user: null, isAuthenticated: false, loading: false })
      }
    } else {
      setAuthState({ user: null, isAuthenticated: false, loading: false })
    }
  }, [])

  const login = async (username: string, password: string) => {
    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      })

      if (!response.ok) {
        throw new Error("Login failed")
      }

      const user = await response.json()
      localStorage.setItem("hospital_user", JSON.stringify(user))
      setAuthState({
        user,
        isAuthenticated: true,
        loading: false,
      })
    } catch (error) {
      throw error
    }
  }

  const signup = async (data: any) => {
    try {
      const response = await fetch("/api/auth/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      })

      if (!response.ok) {
        throw new Error("Signup failed")
      }

      const user = await response.json()
      localStorage.setItem("hospital_user", JSON.stringify(user))
      setAuthState({
        user,
        isAuthenticated: true,
        loading: false,
      })
    } catch (error) {
      throw error
    }
  }

  const logout = () => {
    localStorage.removeItem("hospital_user")
    setAuthState({
      user: null,
      isAuthenticated: false,
      loading: false,
    })
  }

  return <AuthContext.Provider value={{ ...authState, login, signup, logout }}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within AuthProvider")
  }
  return context
}

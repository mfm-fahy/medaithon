"use client"

import { useEffect, useRef, useState } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { mockPatients } from "@/lib/mock-data"
import NurseHeader from "@/components/nurse/nurse-header"

export default function NurseQRScanner() {
  const router = useRouter()
  const { user, isAuthenticated, loading } = useAuth()
  const videoRef = useRef<HTMLVideoElement>(null)
  const [scanned, setScanned] = useState(false)
  const [selectedPatient, setSelectedPatient] = useState<string>("")

  useEffect(() => {
    if (!loading && !isAuthenticated) {
      router.push("/nurse/signin")
    }
  }, [isAuthenticated, loading, router])

  useEffect(() => {
    if (!scanned && videoRef.current) {
      navigator.mediaDevices
        .getUserMedia({ video: { facingMode: "environment" } })
        .then((stream) => {
          if (videoRef.current) {
            videoRef.current.srcObject = stream
          }
        })
        .catch((err) => console.error("Camera access denied:", err))
    }
  }, [scanned])

  const handleSimulateQRScan = () => {
    setScanned(true)
  }

  const handleSelectPatient = (patientId: string) => {
    setSelectedPatient(patientId)
    router.push(`/nurse/vitals-entry?patientId=${patientId}`)
  }

  if (loading) {
    return <div className="flex items-center justify-center min-h-screen">Loading...</div>
  }

  if (!isAuthenticated || user?.role !== "nurse") {
    return null
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <NurseHeader user={user} />

      <main className="max-w-2xl mx-auto p-4 md:p-6">
        <Card>
          <CardHeader>
            <CardTitle>QR Code Scanner</CardTitle>
            <CardDescription>Scan patient wristband QR code</CardDescription>
          </CardHeader>
          <CardContent>
            {!scanned ? (
              <div className="space-y-4">
                <div className="bg-black rounded-lg overflow-hidden aspect-square flex items-center justify-center">
                  <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover" />
                </div>
                <Button onClick={handleSimulateQRScan} className="w-full bg-purple-600 hover:bg-purple-700">
                  Simulate QR Scan
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                  <p className="font-medium text-green-900">QR Code Scanned Successfully!</p>
                  <p className="text-sm text-green-700 mt-1">Select a patient to proceed</p>
                </div>

                <div className="space-y-2">
                  {mockPatients.map((patient) => (
                    <div
                      key={patient.id}
                      onClick={() => handleSelectPatient(patient.id)}
                      className="p-3 border border-gray-200 rounded-lg hover:bg-purple-50 cursor-pointer transition-colors"
                    >
                      <p className="font-medium">{patient.name}</p>
                      <p className="text-sm text-gray-600">ID: {patient.patientId}</p>
                    </div>
                  ))}
                </div>

                <Button onClick={() => setScanned(false)} variant="outline" className="w-full">
                  Scan Again
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  )
}

"use client"

import { useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import PatientHeader from "@/components/patient/patient-header"

export default function NavigationPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const { user, isAuthenticated, loading } = useAuth()
  const disease = searchParams.get("disease")

  useEffect(() => {
    if (!loading && !isAuthenticated) {
      router.push("/patient/signin")
    }
  }, [isAuthenticated, loading, router])

  if (loading) {
    return <div className="flex items-center justify-center min-h-screen">Loading...</div>
  }

  if (!isAuthenticated || user?.role !== "patient") {
    return null
  }

  const destinations = [
    { name: "Doctor Consultation", icon: "👨‍⚕️", room: "101", time: "10:30 AM" },
    { name: "Lab Test", icon: "🧪", room: "Lab-2", time: "11:00 AM" },
    { name: "Injection/IV", icon: "💉", room: "Treatment-1", time: "11:30 AM" },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      <PatientHeader user={user} />

      <main className="max-w-2xl mx-auto p-4 md:p-6">
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Your Visit Plan</CardTitle>
            <CardDescription>Reason for visit: {disease}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {destinations.map((dest, idx) => (
                <div key={idx} className="p-4 border border-gray-200 rounded-lg hover:bg-gray-50">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3">
                      <span className="text-2xl">{dest.icon}</span>
                      <div>
                        <p className="font-medium">{dest.name}</p>
                        <p className="text-sm text-gray-600">Room {dest.room}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium text-blue-600">{dest.time}</p>
                      <p className="text-xs text-gray-500">Estimated</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Important Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            <p>
              <strong>Wristband:</strong> Keep your QR code wristband visible at all times
            </p>
            <p>
              <strong>Check-in:</strong> Report to each department 5 minutes before your scheduled time
            </p>
            <p>
              <strong>Questions:</strong> Ask any staff member for directions
            </p>
          </CardContent>
        </Card>

        <Button onClick={() => router.push("/patient/home")} variant="outline" className="w-full mt-6">
          Back to Home
        </Button>
      </main>
    </div>
  )
}
